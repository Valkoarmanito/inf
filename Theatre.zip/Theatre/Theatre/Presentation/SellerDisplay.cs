﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Spectre.Console;
using Theatre.Data.Models;
using Theatre.Data;

namespace Theatre.Presentation
{
    class SellerDisplay
    {
        public SellerDisplay()
        {
            var highlightStyle = new Style().Foreground(Color.Gold3_1);
            while (true)
            {
                var menuSelector = AnsiConsole.Prompt(
                        new SelectionPrompt<string>()
                        .Title("[gold3_1]Menu[/]")
                        .HighlightStyle(highlightStyle)
                        .AddChoices(new[] {
                        "Add TheatricalGroup", "Add TheatricalPerformance", "Add TypesOFGenre", "Add Theatre", "Add City", "See sold tickets", "[red3]Back[/]"
                        }));

                switch (menuSelector)
                {
                    case "Add TheatricalGroup":
                        {
                            var name = AnsiConsole.Ask<string>("What's the theatrical group's [purple4_1]name[/]?");

                            List<string> typeString = new List<string>();
                            List<TypesOFGenres> typesOFGenres = new TypeOfGenresData().GetGenres();
                            foreach (var type in typesOFGenres)
                            {
                                typeString.Add(type.ToString());
                            }
                            typeString.Add("[red3]Back to the admin menu[/]");

                            var typeSelector = AnsiConsole.Prompt(
                                new SelectionPrompt<string>()
                                .Title("[gold3_1]What's the theatrical group's genre[/]")
                                .HighlightStyle(highlightStyle)
                                .AddChoices(typeString.ToArray()));

                            if (typeSelector == "[red3]Back to the admin menu[/]")
                            {
                                break;
                            }
                            new TheatricalGroupData().Add(new TheatricalGroup(0, name, typesOFGenres[typeString.IndexOf(typeSelector)].TypeOfGenreId));

                            break;
                        }
                    case "Add TypesOFGenre":
                        {
                            var confirm = AnsiConsole.Prompt(
                                new SelectionPrompt<string>()
                                .Title("[gold3_1]Do you want to continue?[/]")
                                .HighlightStyle(highlightStyle)
                                .AddChoices(new[] { "No", "Yes" }));
                            if (confirm.Equals("No"))
                            {
                                break;
                            }
                            new TypeOfGenresData().Add(AnsiConsole.Ask<string>("What's the type of genre [purple4_1]called[/]?"));

                            break;
                        }
                    case "Add TheatricalPerformance":
                        {
                            List<string> thprString = new List<string>();
                            List<TypesOFGenres> typesOFGenres = new TypeOfGenresData().GetGenres();
                            foreach (var type in typesOFGenres)
                            {
                                thprString.Add(type.ToString());
                            }
                            thprString.Add("[red3]Back[/]");

                            var thpSelector = AnsiConsole.Prompt(
                                new SelectionPrompt<string>()
                                .Title("[gold3_1]Who is the theatrical group?[/]")
                                .HighlightStyle(highlightStyle)
                                .AddChoices(thprString.ToArray()));

                            if (thpSelector.Equals("[red3]Back[/]"))
                            {
                                break;
                            }

                            List<string> thString = new List<string>();
                            List<Theatres> theatres = new ThreatresData().GetAllTheaters();
                            foreach (var theatre in theatres)
                            {
                                thString.Add(theatre.ToString());
                            }
                            thString.Add("[red3]Back[/]");

                            var thSelector = AnsiConsole.Prompt(
                                new SelectionPrompt<string>()
                                .Title("[gold3_1]Where is the theatrical performance?[/]")
                                .HighlightStyle(highlightStyle)
                                .AddChoices(thString.ToArray()));

                            if (thSelector.Equals("[red3]Back[/]"))
                            {
                                break;
                            }

                            var dateTime = AnsiConsole.Prompt(
                                new TextPrompt<DateTime>("What's the [purple4_1]date and time[/] of the theatrical performance?")
                                .PromptStyle("green")
                                .ValidationErrorMessage("[red]That's not a valid date and time[/]")
                                .Validate(dateTime =>
                                {
                                    try
                                    {
                                        dateTime.ToString("dd/MMM/yyyy H:mm");
                                        return ValidationResult.Success();
                                    }
                                    catch
                                    {
                                        return ValidationResult.Error("[red]Invalid date and time[/]");
                                    }
                                }));

                            var price = AnsiConsole.Ask<int>("What's the [purple4_1]price[/] of the ticket?");

                            new TheaterPerformencesData().Add(theatres[thString.IndexOf(thSelector)].TheatreId,
                                typesOFGenres[thprString.IndexOf(thpSelector)].TypeOfGenreId, 
                                dateTime,
                                price);

                            break;
                        }

                    case "Add City":
                        {
                            var confirm = AnsiConsole.Prompt(
                                new SelectionPrompt<string>()
                                .Title("[gold3_1]Do you want to continue?[/]")
                                .HighlightStyle(highlightStyle)
                                .AddChoices(new[] { "No", "Yes" }));
                            if (confirm.Equals("No"))
                            {
                                break;
                            }
                            new CitiesData().Add(AnsiConsole.Ask<string>("What's the city [purple4_1]called[/]?"), AnsiConsole.Ask<string>("In which country is [purple4_1]the city[/]?"));

                            break;
                        }
                    case "Add Theatre":
                        {
                            string name = AnsiConsole.Ask<string>("What's the theatre [purple4_1]called[/]?");
                            int seats = AnsiConsole.Ask<int>("How many [purple4_1]seats[/] are there?");

                            List<string> citiesString = new List<string>();
                            List<Cities> cities = new CitiesData().GetCities();
                            foreach (var city in cities)
                            {
                                citiesString.Add(city.ToString());
                            }
                            citiesString.Add("[red3]Back[/]");

                            if (citiesString.Contains("[red3]Back[/]"))
                            {
                                break;
                            }
                            var citySelector = AnsiConsole.Prompt(
                               new SelectionPrompt<string>()
                               .Title("[gold3_1]Where is the theatre?[/]")
                               .HighlightStyle(highlightStyle)
                               .AddChoices(citiesString.ToArray()));

                            new ThreatresData().Add(name, seats, cities[citiesString.IndexOf(citySelector)].CityId);

                            break;
                        }
                    case "See sold tickets":
                        {
                            List<Ticket> tickets = new TicketData().GetSoldTickets();
                            if (tickets.Count == 0)
                            {
                                AnsiConsole.MarkupLine("[red3]No sold tickets found.[/]");
                            }
                            else
                            {
                                foreach (Ticket ticket in tickets)
                                {
                                    AnsiConsole.MarkupLine(ticket.ToString());
                                }
                            }
                            AnsiConsole.Prompt(
                            new SelectionPrompt<string>()
                                .Title("Back to the menu")
                                .HighlightStyle(highlightStyle)
                                .AddChoices(new[] { "Back" }));
                            break;
                        }

                    case "[red3]Back[/]":
                    {
                            Console.Clear();
                            return;
                    }   
                }
            }
        }
    }
}
