﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Spectre.Console;
using Theatre.Data;
using Theatre.Data.Models;

namespace Theatre.Presentation
{
    class TheatersDisplay
    {
        public TheatersDisplay()
        {
            var highlightStyle = new Style().Foreground(Color.Gold3_1);
            List<string> citiesString = new List<string>();
            citiesString.Add("All");
            List<Cities> cities = new CitiesData().GetCities();
            foreach (var city in cities)
            {
                citiesString.Add(city.ToString());
            }
            citiesString.Add("[red3]Back[/]");

            var citySelector = AnsiConsole.Prompt(
                new SelectionPrompt<string>()
                .Title("[gold3_1]Select city[/]")
                .HighlightStyle(highlightStyle)
                .AddChoices(citiesString.ToArray()));

            if (citySelector == "[red3]Back[/]")
            {
                Console.Clear();
                return;
            }

            var table = new Table();
            table.Title(citySelector + " theatricalGroup", new Style().Foreground(Color.DeepPink4).Background(Color.Silver));
            table.AddColumn(new TableColumn("Name").Centered());
            table.AddColumn(new TableColumn("Seats").Centered());
            table.AddColumn(new TableColumn("City").Centered());

            foreach (var theatre in citySelector.Equals("All") ? new ThreatresData().GetAllTheaters() : new ThreatresData().GetTheatresByCity(cities[citiesString.IndexOf(citySelector) - 1].CityId))
            {
                table.AddRow("[blueviolet]" + theatre.TheaterName + "[/]", "[deepskyblue4]" + theatre.Seats + "[/]", new CitiesData().GetCity(theatre.CityId).ToString());
            }
            table.Border(TableBorder.Ascii);
            AnsiConsole.Write(table);
            AnsiConsole.Prompt(
                        new SelectionPrompt<string>()
                        .Title("Back to the menu")
                        .HighlightStyle(highlightStyle)
                        .AddChoices(new[] { "Back" }));
            Console.Clear();
        }
    }
}
