﻿
using System;
using System.Collections.Generic;
using System.Text;
using Spectre.Console;

namespace Theatre.Presentation
{
    internal class Display
    {
        
        public Display()
        {
           

            var highlightStyle = new Style().Foreground(Color.Gold3_1);
            while (true)
            {
                //Prompt for the main menu
                var menuSelector = AnsiConsole.Prompt(
                    new SelectionPrompt<string>()
                    .Title("[gold3_1]Menu[/]")
                    .HighlightStyle(highlightStyle)
                    .AddChoices(new[] {
                        "TheatricalPerformances", "TheatricalGroup", "Theatres", "Sponsors", "Admin", "Exit"
                    }));

                switch (menuSelector)
                {
                    case "TheatricalPerformances":
                        {
                            new TheatricalPerformancesDisplay();
                            break;
                        }
                    case "TheatricalGroup":
                        {
                            new TheatricalGroupDisplay();
                            break;
                        }
                    case "Theatres":
                        {
                            new TheatersDisplay();
                            break;
                        }
                    case "Sponsors":
                        {
                            new SponsorsDisplay();
                            break;
                        }
                    case "Admin":
                        {
                            var password = AnsiConsole.Prompt(
                                                new TextPrompt<string>("Enter [green]password[/]?")
                                                    .PromptStyle("red")
                                                    .Secret());
                            if (password != "thEatre!@#:)")
                            {
                                Console.Clear();
                                break;
                            }
                            new SellerDisplay();
                            break;
                        }
                    case "Exit":
                        {
                            return;
                        }
                }
            }

        }
    }
}
