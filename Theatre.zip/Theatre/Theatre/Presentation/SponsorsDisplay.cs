﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Spectre.Console;
using Theatre.Data;
using Theatre.Data.Models;

namespace Theatre.Presentation
{
    class SponsorsDisplay
    {
        public SponsorsDisplay()
        {
            List<Sponsors> sponsors = new SponsorsData().GetTop3Sponsors();
            AnsiConsole.Write(new BarChart()
            .Width(60)
            .Label("[orangered1 bold underline]Top sponsors in euros[/]")
            .CenterLabel()
            .AddItems(sponsors, (sponsor) => new BarChartItem(
                 sponsor.Name, sponsor.Amount, sponsor.SId % 2 == 0 ? Color.DeepSkyBlue1 : Color.Green3_1)));

            string name = AnsiConsole.Ask<string>("What's your [purple4_1] company name[/]?");
            int amount = AnsiConsole.Prompt(new TextPrompt<int>("How much do you want to be the [deepskyblue2]sponsorship[/]?")
                .ValidationErrorMessage("[red]The sponsorship amount needs to be a positive integer.[/]")
                .Validate(amount =>
                {
                    if (amount < 0) return ValidationResult.Error("[red]The sponsorship amount needs to be a positive integer.[/]");
                    return ValidationResult.Success();
                }
                ));
            string confirm = AnsiConsole.Prompt(
                                new SelectionPrompt<string>()
                                .Title($"[gold3_1]Are you sure you want to make a sponsorship worth of [deepskyblue2]{amount}euros[/] to the Assosiation of Theaters?[/]")
                                .HighlightStyle(new Style().Foreground(Color.Gold3_1))
                                .AddChoices(new[] { "No", "Yes" }));
            if (confirm.Equals("No"))
            {
                AnsiConsole.Clear();
                return;
            }
            new SponsorsData().Add(name, amount);
            AnsiConsole.Prompt(
                       new SelectionPrompt<string>()
                       .Title("[deeppink4_1 bold]Thank you for your generous sponsorship![/]")
                       .HighlightStyle(new Style().Foreground(Color.Gold3_1))
                       .AddChoices(new[] { "Back" }));
            AnsiConsole.Clear();
        }
    }
}
