﻿using System;
using Spectre.Console;
using Theatre.Data.Models;
using Theatre.Data;

namespace Theatre.Presentation
{
    class TheatricalPerformancesDisplay
    {
        public TheatricalPerformancesDisplay()
        {
            var highlightStyle = new Style().Foreground(Color.Gold3_1);
            while (true)
            {
                var menuSelector = AnsiConsole.Prompt(
                        new SelectionPrompt<string>()
                        .Title("[gold3_1]Menu[/]")
                        .HighlightStyle(highlightStyle)
                        .AddChoices(new[] {
                            "All available", "Filter by type of genre", "Filter by city", "Last one and next one theatrical performances", "[red3]Back[/]"
                        }));

                switch (menuSelector)
                {
                    case "All available":
                        {
                            List<string> theatrperfString = new List<string>();
                            var concerts = new TheaterPerformencesData().GetAlltheatricalPerformances();
                            foreach (var theatricalPerformances in concerts)
                            {
                                theatrperfString.Add(theatricalPerformances.ToString());
                            }
                            theatrperfString.Add("[red3]Back[/]");

                            var thperSelector = AnsiConsole.Prompt(
                                new SelectionPrompt<string>()
                                .Title("[gold3_1]All available theatrical performances[/]")
                                .HighlightStyle(highlightStyle)
                                .AddChoices(theatrperfString.ToArray()));

                            if (thperSelector == "[red3]Back[/]") break;

                            TheatricalPerformances performance = concerts[theatrperfString.IndexOf(thperSelector)];
                            BuyTicket(performance.TheatricalPerformancesId, performance.Price == null ? 0 : performance.Price.Value);

                            break;
                        }
                    case "Last one and next one theatrical performances":
                        {
                            List<string> performancesString = new List<string>();
                            var performances = new TheaterPerformencesData().GetAlltheatricalPerformances();
                            foreach (var performance in performances)
                            {
                                performancesString.Add(performance.ToString());
                            }
                            performancesString.Add("[red3]Back[/]");

                            var performanceSelector = AnsiConsole.Prompt(
                                new SelectionPrompt<string>()
                                .Title("[gold3_1]All last ones and next ones theatrical performances[/]")
                                .HighlightStyle(highlightStyle)
                                .AddChoices(performancesString.ToArray()));

                            if (performanceSelector == "[red3]Back[/]") break;

                            break;
                        }
                    case "Filter by type of genre":
                        {
                            
                            break;
                        }
                    case "Filter by city":
                        {
                           
                            break;
                        }
                    case "[red3]Back[/]":
                        {
                            Console.Clear();
                            return;
                        }
                }
            }
        }

        private void BuyTicket(int theatreperformanceId, int price)
        {
            var highlightStyle = new Style().Foreground(Color.Gold3_1);
            string name = AnsiConsole.Ask<string>("What's your [purple4_1]name[/]?");
            var confirm = AnsiConsole.Prompt(
                                new SelectionPrompt<string>()
                                .Title($"[gold3_1]The price of the ticket is [deepskyblue2]{price} euros. [/]Do you want to continue?[/]")
                                .HighlightStyle(highlightStyle)
                                .AddChoices(new[] { "No", "Yes" }));
            if (confirm.Equals("No"))
            {
                return;
            }
            new TicketData().BuyTicket(name, theatreperformanceId);
            AnsiConsole.MarkupLine(new Ticket(name, theatreperformanceId).ToString());
            AnsiConsole.Prompt(
                        new SelectionPrompt<string>()
                        .Title("Back to the menu")
                        .HighlightStyle(highlightStyle)
                        .AddChoices(new[] { "Back" }));
        }
    }
}
