﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Spectre.Console;
using Theatre.Data;
using Theatre.Data.Models;

namespace Theatre.Presentation
{
    class TheatricalGroupDisplay
    {
        public TheatricalGroupDisplay()
        {
            var highlightStyle = new Style().Foreground(Color.Gold3_1);
            List<string> genresString = new List<string>();
            genresString.Add("All");
            List<TypesOFGenres> typesOFGenres = new TypeOfGenresData().GetGenres();
            foreach (var types in typesOFGenres)
            {
                genresString.Add(types.ToString());
            }
            genresString.Add("[red3]Back[/]");

            var genreSelector = AnsiConsole.Prompt(
                new SelectionPrompt<string>()
                .Title("[gold3_1]Select genre[/]")
                .HighlightStyle(highlightStyle)
                .AddChoices(genresString.ToArray()));

            if (genreSelector == "[red3]Back[/]")
            {
                Console.Clear();
                return;
            }


            var table = new Table();
            table.Title(genreSelector + "TheatricalGroups", new Style().Foreground(Color.DeepPink4).Background(Color.Silver));
            table.AddColumn(new TableColumn("Name").Centered());
            table.AddColumn(new TableColumn("Type of genre").Centered());

            foreach (var theatricalGroup in genreSelector.Equals("All") ? new TheatricalGroupData().GetAllTheatricalGroup() : new TheatricalGroupData().GetTheatricalGroupByTypeOfGenre(typesOFGenres[genresString.IndexOf(genreSelector) - 1].TypeOfGenreId))
            {
                table.AddRow("[blueviolet]" + theatricalGroup.TheatricalGroupName + "[/]", "[deepskyblue4]" + theatricalGroup.GetTheatricalGroupGenre() + "[/]");
            }
            table.Border(TableBorder.Ascii);
            AnsiConsole.Write(table);
            AnsiConsole.Prompt(
                        new SelectionPrompt<string>()
                        .Title("Back to the menu")
                        .HighlightStyle(highlightStyle)
                        .AddChoices(new[] { "Back" }));
            Console.Clear();
        }
    }
}
