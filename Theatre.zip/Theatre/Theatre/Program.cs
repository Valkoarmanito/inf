﻿using Theatre.Presentation;

namespace Theatre
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Display d = new Display();

        }
    }
}
