﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Theatre.Data.Models;

namespace Theatre.Data
{
    class ThreatresData
    {
        public string GetTheaterName(int id)
        {
            using (var connection = DataBase.GetConnection())
            {
                var command = new SqlCommand($"SELECT h.Hall_Name, c.CIty_Name FROM Halls h join Cities c on h.City_ID=c.City_ID where h.Halls_ID={id}", connection);
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        return reader.GetString(0) + ", " + reader.GetString(1);
                    }

                }
                connection.Close();
            }
            return "";
        }
        public List<Theatres> GetAllTheaters()
        {
            List<Theatres> theatres = new List<Theatres>();
            using (var connection = DataBase.GetConnection())
            {
                var command = new SqlCommand("SELECT * FROM Halls order by No_Of_Seats desc", connection);
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var theatres1 = new Theatres(
                            reader.GetInt32(0),
                            reader.GetString(1),
                            reader.GetInt32(2),
                            reader.GetInt32(3)
                        );

                        theatres.Add(theatres1);
                    }

                }
                connection.Close();
            }
            return theatres;
        }
        public List<Theatres> GetTheatresByCity(int id)
        {
            List<Theatres> theatres = new List<Theatres>();
            using (var connection = DataBase.GetConnection())
            {
                var command = new SqlCommand($"SELECT * FROM Halls WHERE City_ID={id} order by No_Of_Seats desc", connection);
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var theatres1 = new Theatres(
                            reader.GetInt32(0),
                            reader.GetString(1),
                            reader.GetInt32(2),
                            reader.GetInt32(3)
                        );

                        theatres.Add(theatres1);
                    }

                }
                connection.Close();
            }
            return theatres;
        }
        public void Add(string name, int seats, int cityId)
        {
            using (var connection = DataBase.GetConnection())
            {
                var command = new SqlCommand("INSERT INTO Halls (Hall_Name, City_ID, No_Of_Seats) VALUES(@name, @cityId, @seats)", connection);
                command.Parameters.AddWithValue("name", name);
                command.Parameters.AddWithValue("cityId", cityId);
                command.Parameters.AddWithValue("seats", seats);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }
        public Theatres GetTheatreById(int id)
        {
            using (var connection = DataBase.GetConnection())
            {
                var command = new SqlCommand($"SELECT * FROM Halls where Halls_ID={id}", connection);
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        return new Theatres(
                            reader.GetInt32(0),
                            reader.GetString(1),
                            reader.GetInt32(2),
                            reader.GetInt32(3)
                        );
                    }

                }
                connection.Close();
            }
            return new Theatres();
        }

        internal IEnumerable<object> GetAllTheatres()
        {
            throw new NotImplementedException();
        }
    }
}
