﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Theatre.Data.Models;

namespace Theatre.Data
{
    class TheatricalGroupData
    {
        public string GetTheatricalGroupDataName(int id)
        {
            using (var connection = DataBase.GetConnection())
            {
                var command = new SqlCommand($"SELECT TheatricalGroupName FROM TheatricalGroup WHERE TheatricalGroupId=@id", connection);
                command.Parameters.AddWithValue("@id", id);
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        return reader.GetString(0);
                    }
                }
            }
            return "";
        }

        public List<TheatricalGroup> GetAllTheatricalGroup()
        {
            List<TheatricalGroup> theatricalGroups = new List<TheatricalGroup>();
            using (var connection = DataBase.GetConnection())
            {
                var command = new SqlCommand("SELECT * FROM TheatricalGroup Order by TypeOfGenreId, TheatricalGroupName", connection);
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var theatrical = new TheatricalGroup(
                            reader.GetInt32(0),
                            reader.GetString(1),
                            reader.GetInt32(2)
                        );

                        theatricalGroups.Add(theatrical);
                    }
                }
            }
            return theatricalGroups;
        }

        public List<TheatricalGroup> GetTheatricalGroupByTypeOfGenre(int id)
        {
            List<TheatricalGroup> theatricalGroups = new List<TheatricalGroup>();
            using (var connection = DataBase.GetConnection())
            {
                var command = new SqlCommand("SELECT * FROM TheatricalGroup WHERE TypeOfGenreId=@id Order by TheatricalGroupName", connection);
                command.Parameters.AddWithValue("@id", id);
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var theatrical = new TheatricalGroup(
                            reader.GetInt32(0),
                            reader.GetString(1),
                            reader.GetInt32(2)
                            
                    );

                        theatricalGroups.Add(theatrical);
                    }
                }
            }
            return theatricalGroups;
        }

        public void Add(TheatricalGroup theatricalGroup)
        {
            using (var connection =DataBase.GetConnection())
            {
                var command = new SqlCommand("INSERT INTO TheatricalGroups (TheatricalGroupName, NumberOfPerformers, TypeOfGenreId) VALUES(@name, @numPerformers, @genreId)", connection);
                command.Parameters.AddWithValue("@name", theatricalGroup.TheatricalGroupName);
                command.Parameters.AddWithValue("@numPerformers", theatricalGroup.NumberOfPerformers);
                command.Parameters.AddWithValue("@genreId", theatricalGroup.TypeOfGenreId);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }
}
