﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Theatre.Data.Models
{
    class Sponsors
    {

        public Sponsors(int id, string name, int amount)
        {
            SId = id;
            Name = name;
            Amount = amount;
        }
        public int SId { get; set; }
        public string Name { get; set; }
        public int Amount { get; set; }

        public override string ToString()
        {
            return Name + " - " + Amount;
        }

    }
}
