﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Theatre.Data.Models
{
    internal class TypesOFGenres
    {
        public TypesOFGenres()
        {
            TheatricalGroups = new HashSet<TheatricalGroup>();
        }
        public TypesOFGenres(int id, string name)
        {
            TypeOfGenreId = id;
            Name = name;
        }

        public int TypeOfGenreId { get; set; }
        public string Name { get; set; }

        public virtual ICollection<TheatricalGroup> TheatricalGroups { get; set; }

        public override string ToString()
        {
            return Name;
        }
    }
}
