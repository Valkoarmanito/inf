﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Theatre.Data.Models
{
    class Ticket
    {
        public Ticket(string name, int Id)
        {
            Name = name;
            TheatricalPerformancesId = Id;
        }
        public Ticket(int id, string name, int Id)
        {
            TicketId = id;
            Name = name;
            TheatricalPerformancesId = Id;
        }
        public int TicketId { get; set; }
        public string Name { get; set; }
        public int TheatricalPerformancesId { get; set; }

        public virtual TheatricalPerformances TheatricalPerformance { get; set; }

        public override string ToString()
        {
            TheatricalPerformances c = new TheaterPerformencesData().getTheatricalPerformancesById(TheatricalPerformancesId);
            string s =
            "[gold1]******************************************************[/]" + "\n" +
            "[gold1]\\    ╔════╦══╦═══╦╗╔═╦═══╦════╗    /[/]" + "\n" +
             "[gold1]/    ║╔╗╔╗╠╣╠╣╔═╗║║║╔╣╔══╣╔╗╔╗║    \\[/]" + "\n" +
            "[gold1]\\    ╚╝║║╚╝║║║║ ╚╣╚╝╝║╚══╬╝║║╚╝    /[/]" + "\n" +
             "[gold1]/      ║║  ║║║║ ╔╣╔╗║║╔══╝ ║║      \\[/]" + "\n" +
            "[gold1]\\      ║║ ╔╣╠╣╚═╝║║║╚╣╚══╗ ║║      /[/]" + "\n" +
             "[gold1]/      ╚╝ ╚══╩═══╩╝╚═╩═══╝ ╚╝      \\[/]" + "\n" +
            "[gold1]\\                                                    /[/]" + "\n" +
            $"[gold1]/{FillUpBlankSpace("  NAME: " + Name)}\\[/]" + "\n" +
            $"[gold1]\\{FillUpBlankSpace("  DATE AND TIME: " + c.DateAndTime)}/[/]" + "\n" +
            $"[gold1]/{FillUpBlankSpace("  LOCATION: " + new ThreatresData().GetTheatreById(c.TheaterId).ToStringNoMarkup())}\\[/]" + "\n" +
            $"[gold1]\\                                                    /[/]" + "\n" +
            "[gold1]******************************************************[/]";
            return s;
        }
        private string FillUpBlankSpace(string name)
        {
            if (name.Length >= 52) return name.Substring(0, 52);
            int n = 52 - name.Length;
            return name + string.Concat(Enumerable.Repeat(' ', n));
        }
    }
}
