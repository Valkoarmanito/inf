﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Theatre.Data.Models
{
    class Theatres
    {

        public Theatres()
        {
            TheatricalPerformances = new HashSet<TheatricalPerformances>();
        }
        public Theatres(int id, string name, int cityId, int seats)
        {
            TheatreId = id;
            TheaterName = name;
            CityId = cityId;
            Seats = seats;
        }

        public int TheatreId { get; set; }
        public string TheaterName { get; set; }
        public int CityId { get; set; }
        public int Seats { get; set; }

        public virtual Cities City { get; set; }
        public virtual ICollection<TheatricalPerformances> TheatricalPerformances { get; set; }

        public override string ToString()
        {
            return $"[green3]{TheaterName}, {new CitiesData().GetCity(CityId).CityName}[/]";
        }
        public string ToStringNoMarkup()
        {
            return $"{TheaterName}, {new CitiesData().GetCity(CityId).CityName}";
        }
    }
}
