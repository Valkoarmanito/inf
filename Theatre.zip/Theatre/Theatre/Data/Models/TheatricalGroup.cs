﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Theatre.Data.Models
{
    class TheatricalGroup
    {
        public TheatricalGroup()
        {
            TheatricalPerformances = new HashSet<TheatricalPerformances>();
        }
        public TheatricalGroup(int id, string name,int gId)
        {
            TheatricalGroupId = id;
            TheatricalGroupName = name;
            TypeOfGenreId = gId;

        }

        public int TheatricalGroupId { get; set; }
        public string TheatricalGroupName { get; set; }
        public int NumberOfPerformers { get; set; }
        public int TypeOfGenreId { get; set; }

        public virtual TypesOFGenres TypesOFGenres { get; set; }
        public virtual ICollection<TheatricalPerformances> TheatricalPerformances { get; set; }

        public override string ToString()
        {
            return TheatricalGroupName + " - genre: " + GetTheatricalGroupGenre();
        }
        public string GetTheatricalGroupGenre()
        {
            return new TypeOfGenresData().GetTypeGenreById(TypeOfGenreId);
        }
    }
}
