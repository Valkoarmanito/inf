﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Theatre.Data.Models
{
    class TheatricalPerformances
    {
        public TheatricalPerformances()
        {
            SoldTickets = new HashSet<Ticket>();
        }
        public TheatricalPerformances(int Id, int theaterId, int theatricalGroupId, DateTime dateTime, bool available,int price)
        {
            TheatricalPerformancesId = Id;
            TheaterId = theaterId;
            TheatricalGroupId = theatricalGroupId;
            DateAndTime = dateTime;
            Price = price;
        }

        public int TheatricalPerformancesId { get; set; }
        public int TheaterId { get; set; }
        public int TheatricalGroupId { get; set; }
        public DateTime DateAndTime { get; set; }
        public bool Available { get; set; }

        public int? Price { get; set; }

        public virtual Theatres Theatres { get; set; }
        public virtual TheatricalGroup TheatricalGroup { get; set; }
        public virtual ICollection<Ticket> SoldTickets { get; set; }

        public override string ToString()
        {
            string dateTime = DateAndTime.ToString("dd/MMM/yyyy H:mm");
            return $"[violet]{new TheatricalGroupData().GetTheatricalGroupDataName(TheatricalGroupId)}[/], [orange3]{new ThreatresData().GetTheaterName(TheaterId)}[/], [yellow1]{dateTime}[/], [deepskyblue2]{Price}BGN[/]";
        }
    }
}
