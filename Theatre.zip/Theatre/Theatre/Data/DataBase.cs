﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace Theatre.Data
{
    public static class DataBase
    {
        private static string connectionString = "LAPTOP-CF5E3STP\\SQLEXPRESS; Database=Theatre; Integrated Security=true";
        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}
