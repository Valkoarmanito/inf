﻿using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Theatre.Data.Models;

namespace Theatre.Data
{
    class TypeOfGenresData
    {
        public List<TypesOFGenres> GetGenres()
        {
            List<TypesOFGenres> typeofgenres = new List<TypesOFGenres>();
            using (var connection = DataBase.GetConnection())
            {
                var command = new SqlCommand("SELECT * FROM TypesOFGenres", connection);
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var genre1 = new TypesOFGenres(
                            reader.GetInt32(0),
                            reader.GetString(1)
                        );

                        typeofgenres.Add(genre1);
                    }
                }
            }
            return typeofgenres;
        }

        public string GetTypeGenreById(int id)
        {
            using (var connection = DataBase.GetConnection())
            {
                var command = new SqlCommand("SELECT Name FROM TypesOFGenres WHERE TypesOFGenreId=@id", connection);
                command.Parameters.AddWithValue("@id", id);
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        return reader.GetString(0);
                    }
                }
            }
            return "";
        }

        public void Add(string name)
        {
            using (var connection = DataBase.GetConnection())
            {
                var command = new SqlCommand("INSERT INTO TypesOFGenres (Name) VALUES(@name)", connection);
                command.Parameters.AddWithValue("@name", name);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }
}
