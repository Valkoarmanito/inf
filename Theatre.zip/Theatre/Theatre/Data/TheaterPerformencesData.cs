﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Theatre.Data.Models;

namespace Theatre.Data
{
     class TheaterPerformencesData
    {
        public List<TheatricalPerformances> GetAlailableTheatricalPerformances()
        {
            List<TheatricalPerformances> theaterPerformences = new List<TheatricalPerformances>();
            using (var connection = DataBase.GetConnection())
            {
                var command = new SqlCommand("SELECT * FROM TheatricalPerformances WHERE Available='true' Order by DateAndTime", connection);
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var theaterPerformences1 = new TheatricalPerformances(
                            reader.GetInt32(0),
                            reader.GetInt32(1),
                            reader.GetInt32(2),
                            reader.GetDateTime(3),
                            reader.GetBoolean(4),
                            reader.GetInt32(5)
                        );

                        theaterPerformences.Add(theaterPerformences1);
                    }

                }
                connection.Close();
            }
            return theaterPerformences;
        }
        public List<TheatricalPerformances> GetByTheatricalPerformancesCity(int id)
        {
            List<TheatricalPerformances> theatricalPerformances = new List<TheatricalPerformances>();
            using (var connection = DataBase.GetConnection())
            {
                var command = new SqlCommand($"select c.* from TheatricalPerformances c join TheatricalGroups p on p.TheatricalGroupId=c.TheatricalGroupId join Theatres t on t.TheaterId=c.TheaterId join Cities cty on cty.CityID=t.CityID WHERE c.Available='true' and cty.CityID={id} Order by c.DateAndTime", connection);
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var theatricalPerformances1 = new TheatricalPerformances(
                            reader.GetInt32(0),
                            reader.GetInt32(1),
                            reader.GetInt32(2),
                            reader.GetDateTime(3),
                            reader.GetBoolean(4),
                            reader.GetInt32(5)
                        );

                        theatricalPerformances.Add(theatricalPerformances1);
                    }

                }
                connection.Close();
            }
            return theatricalPerformances;
        }
        public List<TheatricalPerformances> GetTheatricalPerformancesByTypeOfGenre(int id)
        {
            List<TheatricalPerformances> theatricalPerformances = new List<TheatricalPerformances>();
            using (var connection = DataBase.GetConnection())
            {
                var command = new SqlCommand($"SELECT * FROM TheatricalPerformances th join TheatricalGroups tg on tg.TheatricalGroupId=th.TheatricalGroupId join TypesOFGenres g on tg.TypeOfGenreId=g.TypeOfGenreId where th.Available='true' and g.TypeOfGenreId={id} Order by th.DateAndTime", connection);
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var theatricalPerformances1 = new TheatricalPerformances(
                            reader.GetInt32(0),
                            reader.GetInt32(1),
                            reader.GetInt32(2),
                            reader.GetDateTime(3),
                            reader.GetBoolean(4),
                            reader.GetInt32(5)
                        );
                        theatricalPerformances.Add(theatricalPerformances1);
                    }

                }
                connection.Close();
            }
            return theatricalPerformances;
        }
        public List<TheatricalPerformances> GetAlltheatricalPerformances()
        {
            List<TheatricalPerformances> theatricalPerformances = new List<TheatricalPerformances>();
            using (var connection = DataBase.GetConnection())
            {
                var command = new SqlCommand("SELECT * FROM TheatricalPerformances Order by DateAndTime", connection);
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var theatricalPerformances1 = new TheatricalPerformances(
                            reader.GetInt32(0),
                            reader.GetInt32(1),
                            reader.GetInt32(2),
                            reader.GetDateTime(3),
                            reader.GetBoolean(4),
                            reader.GetInt32(5)
                            
                            );

                        theatricalPerformances.Add(theatricalPerformances1);
                    }

                }
                connection.Close();
            }
            return theatricalPerformances;
        }
        public TheatricalPerformances getTheatricalPerformancesById(int id)
        {
            using (var connection = DataBase.GetConnection())
            {
                var command = new SqlCommand($"SELECT * FROM TheatricalPerformances where TheatricalPerformancesId ={id}", connection);
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        return new TheatricalPerformances(
                            reader.GetInt32(0),
                            reader.GetInt32(1),
                            reader.GetInt32(2),
                            reader.GetDateTime(3),
                            reader.GetBoolean(4),
                            reader.GetInt32(5)
                        );
                    }

                }
                connection.Close();
            }
            return new TheatricalPerformances();
        }
        public void Add(int TheaterId, int TheatricalGroupId, DateTime dateTime, int price )
        {
            using (var connection = DataBase.GetConnection())
            {
                var command = new SqlCommand("INSERT INTO TheatricalPerformances (TheaterId, TheatricalGroupId, DateAndTime, Available, Price) VALUES(@hallId, @performerId, @dateTime, @available, @price)", connection);
                command.Parameters.AddWithValue("hallId", TheaterId);
                command.Parameters.AddWithValue("performerId", TheatricalGroupId);
                command.Parameters.AddWithValue("dateTime", dateTime);
                command.Parameters.AddWithValue("available", true);
                command.Parameters.AddWithValue("price", price);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }

        
    }
}
