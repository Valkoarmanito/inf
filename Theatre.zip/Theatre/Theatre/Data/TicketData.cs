﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Theatre.Data.Models;

namespace Theatre.Data
{
    class TicketData
    {
        public void BuyTicket(string name, int TheatricalPerformancesId)
        {
            TheatricalPerformances c = new TheaterPerformencesData().getTheatricalPerformancesById(TheatricalPerformancesId);
            if (GetSoldTicketsByTheatricalPerformancesId(TheatricalPerformancesId) + 1 >= new ThreatresData().GetTheatreById(c.TheaterId).Seats)
            {
                using (var connection = DataBase.GetConnection())
                {
                    var command = new SqlCommand($"Update TheatricalPerformances SET Available={false} WHERE TheatricalPerformancesId={TheatricalPerformancesId}", connection);
                    connection.Open();
                    command.ExecuteNonQuery();
                    var command2 = new SqlCommand("INSERT INTO Ticket (Name, TheatricalPerformancesId) VALUES(@name, @theatricalPerformancesId)", connection);
                    command2.Parameters.AddWithValue("name", name);
                    command2.Parameters.AddWithValue("theatricalPerformancesId", TheatricalPerformancesId);
                    command2.ExecuteNonQuery();
                    connection.Close();
                }
                return;
            }
            using (var connection = DataBase.GetConnection())
            {
                var command = new SqlCommand("INSERT INTO Ticket (Name, TheatricalPerformancesId) VALUES(@name, @theatricalPerformancesId)", connection);
                command.Parameters.AddWithValue("name", name);
                command.Parameters.AddWithValue("theatricalPerformancesId", TheatricalPerformancesId);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }
        public int GetSoldTicketsByTheatricalPerformancesId(int id)
        {
            using (var connection = DataBase.GetConnection())
            {
                var command = new SqlCommand($"SELECT COUNT(TheatricalPerformancesId) FROM Ticket WHERE theatricalPerformancesId={id}", connection);
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        return reader.GetInt32(0);
                    }

                }
                connection.Close();
            }
            return 0;
        }
        public List<Ticket> GetSoldTickets()
        {
            List<Ticket> tickets = new List<Ticket>();
            using (var connection = DataBase.GetConnection())
            {
                var command = new SqlCommand("SELECT * FROM Ticket", connection);
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var ticket = new Ticket(
                            reader.GetInt32(0),
                            reader.GetString(1),
                            reader.GetInt32(2)
                        );

                        tickets.Add(ticket);
                    }

                }
                connection.Close();
            }
            return tickets;
        }
    }
}
