﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Theatre.Data.Models;

namespace Theatre.Data
{
    class SponsorsData
    {
            public void Add(string name, int amount)
            {
                using (var connection = DataBase.GetConnection())
                {
                    var command = new SqlCommand("INSERT INTO Sponsors (Name, Amount) VALUES(@name, @amount)", connection);
                    command.Parameters.AddWithValue("name", name);
                    command.Parameters.AddWithValue("amount", amount);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
            public List<Sponsors> GetTop3Sponsors()
            {
                List<Sponsors> sponsors = new List<Sponsors>();
                using (var connection = DataBase.GetConnection())
                {
                    var command = new SqlCommand("SELECT Top 3 s.Name, sum(s.Amount) as Amount FROM Sponsors s group by s.Name order by Amount desc", connection);
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        int n = 0;
                        while (reader.Read())
                        {
                            var sponsors1 = new Sponsors(
                                n,
                                reader.GetString(0),
                                reader.GetInt32(1)
                            );
                            n++;
                            sponsors.Add(sponsors1);
                        }

                    }
                    connection.Close();
                }
                return sponsors;
            }
    }
}

